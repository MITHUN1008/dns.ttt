
import React from 'react';
import Header from '../components/Header';
import TicTacToe from '../components/TicTacToe';

const Index = () => {
  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-start py-12 px-4 bg-premium-gradient">
      <div className="w-full max-w-3xl">
        <Header />
        <main className="flex flex-col items-center">
          <TicTacToe />
        </main>
        <footer className="mt-12 text-center text-muted-foreground text-sm">
          <p>Tic Tac Toe &copy; {new Date().getFullYear()}</p>
        </footer>
      </div>
    </div>
  );
};

export default Index;
