import React, { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Trophy, RotateCcw, X, Circle } from 'lucide-react';

type Player = 'X' | 'O';
type BoardState = (Player | null)[];
type WinnerLineType = {
  line: number[];
  direction: 'horizontal' | 'vertical' | 'diagonal' | 'diagonal-reverse';
} | null;

const WINNING_COMBINATIONS = [
  // Rows
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  // Columns
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  // Diagonals
  [0, 4, 8],
  [2, 4, 6],
];

const TicTacToe: React.FC = () => {
  const [board, setBoard] = useState<BoardState>(Array(9).fill(null));
  const [currentPlayer, setCurrentPlayer] = useState<Player>('X');
  const [scores, setScores] = useState({ X: 0, O: 0 });
  const [gameOver, setGameOver] = useState(false);
  const [winnerLine, setWinnerLine] = useState<WinnerLineType>(null);
  const [isRestarting, setIsRestarting] = useState(false);
  const { toast } = useToast();

  const handleCellClick = (index: number) => {
    if (board[index] || gameOver) return;

    const newBoard = [...board];
    newBoard[index] = currentPlayer;
    setBoard(newBoard);

    const result = checkWinner(newBoard);
    
    if (result) {
      setGameOver(true);
      setWinnerLine(result);
      setScores(prev => ({
        ...prev,
        [currentPlayer]: prev[currentPlayer] + 1
      }));
      
      setTimeout(() => {
        toast({
          title: `Player ${currentPlayer} Wins!`,
          description: "Congratulations on your victory!",
          className: "bg-black border border-gold/30",
        });
      }, 500);
    } else if (newBoard.every(cell => cell !== null)) {
      setGameOver(true);
      
      setTimeout(() => {
        toast({
          title: "It's a Draw!",
          description: "No winner this time.",
          className: "bg-black border border-gold/30",
        });
      }, 500);
    } else {
      setCurrentPlayer(currentPlayer === 'X' ? 'O' : 'X');
    }
  };

  const checkWinner = (board: BoardState): WinnerLineType => {
    for (const combo of WINNING_COMBINATIONS) {
      const [a, b, c] = combo;
      if (board[a] && board[a] === board[b] && board[a] === board[c]) {
        // Determine the direction of the winning line
        let direction: 'horizontal' | 'vertical' | 'diagonal' | 'diagonal-reverse';
        
        if (combo[0] % 3 === 0 && combo[1] === combo[0] + 1) {
          direction = 'horizontal';
        } else if (combo[0] < 3 && combo[1] === combo[0] + 3) {
          direction = 'vertical';
        } else if (combo[0] === 0 && combo[2] === 8) {
          direction = 'diagonal';
        } else {
          direction = 'diagonal-reverse';
        }
        
        return { line: combo, direction };
      }
    }
    return null;
  };

  const restartGame = () => {
    setIsRestarting(true);
    setTimeout(() => {
      setBoard(Array(9).fill(null));
      setGameOver(false);
      setWinnerLine(null);
      setCurrentPlayer('X');
      setIsRestarting(false);
    }, 300);
  };

  const resetScores = () => {
    setScores({ X: 0, O: 0 });
    restartGame();
    toast({
      title: "Scores Reset",
      description: "The scoreboard has been cleared.",
      className: "bg-black border border-gold/30",
    });
  };

  const renderWinnerLine = () => {
    if (!winnerLine) return null;
    
    const { line, direction } = winnerLine;
    const row = Math.floor(line[0] / 3);
    const col = line[0] % 3;
    
    let styles: React.CSSProperties = {};
    
    switch (direction) {
      case 'horizontal':
        styles = {
          top: `calc(${row * 33.33}% + 16.67%)`,
          left: '5%',
          width: '90%',
          height: '4px',
        };
        break;
      case 'vertical':
        styles = {
          top: '5%',
          left: `calc(${col * 33.33}% + 16.67%)`,
          width: '4px',
          height: '90%',
        };
        break;
      case 'diagonal':
        styles = {
          top: '5%',
          left: '5%',
          width: '130%',
          height: '4px',
          transform: 'rotate(45deg)',
          transformOrigin: 'top left',
        };
        break;
      case 'diagonal-reverse':
        styles = {
          top: '5%',
          right: '5%',
          width: '130%',
          height: '4px',
          transform: 'rotate(-45deg)',
          transformOrigin: 'top right',
        };
        break;
    }
    
    return <div className="winner-line" style={styles}></div>;
  };

  return (
    <div className="w-full flex flex-col items-center animate-fade-in">
      <div className="flex justify-between items-center w-full max-w-md mb-6">
        <div className="flex flex-col items-center">
          <div className="flex items-center space-x-2">
            <X className="h-6 w-6 text-blue-400" />
            <span className="text-white text-xl">Player X</span>
          </div>
          <span className="premium-text text-2xl font-bold">{scores.X}</span>
        </div>
        
        <div className="flex flex-col items-center">
          <div className="flex items-center space-x-2">
            <Circle className="h-6 w-6 text-gold" />
            <span className="text-white text-xl">Player O</span>
          </div>
          <span className="premium-text text-2xl font-bold">{scores.O}</span>
        </div>
      </div>
      
      <Card className="purple-black-board w-full max-w-md aspect-square relative overflow-hidden rounded-3xl p-3">
        <div 
          className={`grid grid-cols-3 grid-rows-3 h-full gap-3 ${isRestarting ? 'opacity-0' : 'opacity-100'} transition-opacity duration-300`}
        >
          {board.map((cell, index) => (
            <div
              key={index}
              className={`board-cell bg-purple-black/90 border-2 border-gold/20 hover:border-gold/40 rounded-xl shadow-inner shadow-purple-900/50 ${
                winnerLine && winnerLine.line.includes(index) ? 'winner-cell' : ''
              } ${cell ? 'animate-cell-appear' : ''}`}
              onClick={() => handleCellClick(index)}
            >
              {cell === 'X' && <X className="h-12 w-12 cell-x" />}
              {cell === 'O' && <Circle className="h-12 w-12 cell-o" />}
            </div>
          ))}
          {renderWinnerLine()}
        </div>
      </Card>
      
      <div className="mt-6 flex space-x-4 animate-slide-up">
        <Button 
          onClick={restartGame} 
          className="premium-button flex items-center gap-2"
        >
          <RotateCcw className="h-4 w-4" />
          New Game
        </Button>
        
        <Button 
          onClick={resetScores} 
          className="premium-button flex items-center gap-2"
        >
          <Trophy className="h-4 w-4" />
          Reset Scores
        </Button>
      </div>
      
      <div className="mt-6 text-center">
        {!gameOver && (
          <div className="flex items-center justify-center animate-pulse-glow">
            <span className="text-white mr-2">Current Player:</span>
            {currentPlayer === 'X' ? (
              <X className="h-6 w-6 text-blue-400" />
            ) : (
              <Circle className="h-6 w-6 text-gold" />
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default TicTacToe;
