
import React from 'react';
import { SquareUser, Trophy } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="w-full py-4 flex flex-col items-center mb-6">
      <div className="flex items-center justify-center mb-2">
        <SquareUser className="w-8 h-8 mr-3 text-gold" />
        <h1 className="text-4xl font-bold premium-text">Tic Tac Toe</h1>
        <Trophy className="w-8 h-8 ml-3 text-gold" />
      </div>
      <p className="text-gray-400 text-center max-w-md">
        Experience tic-tac-toe with a premium dark interface. Take turns and claim victory.
      </p>
    </header>
  );
};

export default Header;
